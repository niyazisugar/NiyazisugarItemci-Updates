(() => {
    "use strict";

    if (window.__niyaziQuickDockV24Installed) {
        window.__niyaziQuickDockV24Refresh?.();
        return;
    }

    window.__niyaziQuickDockV24Installed = true;

    // Kullanıcının istediği SADECE üç hazır cevap.
    // Buton isimleri kısa, gönderilen metinler tamdır.
    const REPLIES = [
        {
            id:"ch1",
            short:"CH1 Depo",
            text:"CH1 depocudayım, bekliyorum.",
            key:"Alt+1",
            tone:"blue"
        },
        {
            id:"pazar",
            short:"Pazara At",
            text:"Pazara item at, çekeyim.",
            key:"Alt+2",
            tone:"blue"
        },
        {
            id:"onay",
            short:"Onay + Değerlendirme",
            text:"Onay yolladım, hayırlı olsun. Başka bir şey lazım olursa yazabilirsin. Bir de değerlendirme atarsan iyi olur kankam.",
            key:"Alt+3",
            tone:"gold"
        }
    ];

    const state = {
        panel:null,
        mini:null,
        direct:false,
        minimized:true,
        dragging:false,
        dragEl:null,
        dragMoved:false,
        suppressClick:false,
        startX:0,
        startY:0,
        offsetX:0,
        offsetY:0,
        x:null,
        y:null,
        observer:null,
        raf:0
    };

    const STORAGE = {
        direct:"niyazi_qr_direct_v24",
        minimized:"niyazi_qr_min_v24",
        x:"niyazi_qr_x_v24",
        y:"niyazi_qr_y_v24"
    };

    function loadState() {
        try {
            state.direct = localStorage.getItem(STORAGE.direct) === "1";
            state.minimized = localStorage.getItem(STORAGE.minimized) !== "0";

            const x = Number(localStorage.getItem(STORAGE.x));
            const y = Number(localStorage.getItem(STORAGE.y));

            state.x = Number.isFinite(x) && x >= 0 ? x : null;
            state.y = Number.isFinite(y) && y >= 0 ? y : null;
        } catch {}
    }

    function savePosition(x,y) {
        state.x = x;
        state.y = y;

        try {
            localStorage.setItem(STORAGE.x,String(Math.round(x)));
            localStorage.setItem(STORAGE.y,String(Math.round(y)));
        } catch {}
    }

    function isMessagesPage() {
        const p = String(location.pathname || "").toLocaleLowerCase("tr-TR");

        return (
            p.includes("/panel/mesaj") ||
            p.includes("/messages") ||
            p.includes("/message") ||
            p.includes("/chat")
        );
    }

    const norm = v => String(v || "")
        .toLocaleLowerCase("tr-TR")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g,"")
        .replace(/ı/g,"i")
        .replace(/\s+/g," ")
        .trim();

    const visible = el => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);

        return (
            r.width > 0 &&
            r.height > 0 &&
            s.display !== "none" &&
            s.visibility !== "hidden"
        );
    };

    function findMessageInput() {
        const candidates = [
            ...document.querySelectorAll("textarea"),
            ...document.querySelectorAll('[contenteditable="true"]'),
            ...document.querySelectorAll('input[type="text"]')
        ].filter(visible);

        const scored = candidates.map(el => {
            const placeholder = norm(el.getAttribute("placeholder"));
            const aria = norm(el.getAttribute("aria-label"));
            const cls = norm(el.className || "");
            const parent = norm(el.parentElement?.textContent || "");
            const r = el.getBoundingClientRect();

            let score = 0;

            if (el.tagName === "TEXTAREA") score += 12;
            if (el.getAttribute("contenteditable") === "true") score += 10;
            if (placeholder.includes("mesaj")) score += 25;
            if (placeholder.includes("yaz")) score += 9;
            if (aria.includes("mesaj")) score += 15;
            if (cls.includes("message")) score += 10;
            if (cls.includes("chat")) score += 10;
            if (parent.includes("gonder") || parent.includes("gönder")) score += 6;

            if (r.left > window.innerWidth * .30) score += 7;
            if (r.top > window.innerHeight * .38) score += 5;

            if (placeholder.includes("kullanici") || placeholder.includes("kullanıcı")) score -= 40;
            if (placeholder.includes("ara")) score -= 20;

            return {el,score};
        }).sort((a,b) => b.score-a.score);

        return scored[0]?.score >= 12
            ? scored[0].el
            : null;
    }

    function setValue(target,value) {
        if (!target) return false;

        target.focus();

        if (target.getAttribute("contenteditable") === "true") {
            target.innerHTML = "";
            target.textContent = value;

            target.dispatchEvent(new InputEvent("input",{
                bubbles:true,
                inputType:value ? "insertText" : "deleteContentBackward",
                data:value || null
            }));

            target.dispatchEvent(new Event("change",{bubbles:true}));
            return true;
        }

        const proto = target.tagName === "TEXTAREA"
            ? HTMLTextAreaElement.prototype
            : HTMLInputElement.prototype;

        const setter = Object.getOwnPropertyDescriptor(proto,"value")?.set;

        if (setter) setter.call(target,value);
        else target.value = value;

        target.dispatchEvent(new Event("input",{bubbles:true}));
        target.dispatchEvent(new Event("change",{bubbles:true}));

        return true;
    }

    function clearMessage() {
        const target = findMessageInput();

        if (!target) {
            flash("Önce konuşmayı aç",false);
            return;
        }

        setValue(target,"");
        target.focus();
        flash("Mesaj temizlendi ✓");
    }

    async function trySend(target) {
        await new Promise(r => setTimeout(r,230));

        const form = target.closest("form");

        if (form) {
            const best = [...form.querySelectorAll('button,input[type="submit"],[role="button"]')]
                .filter(el => visible(el) && !el.disabled)
                .map(el => {
                    const t = norm(el.textContent);
                    const a = norm(el.getAttribute("aria-label"));
                    const title = norm(el.getAttribute("title"));
                    const cls = norm(el.className || "");
                    let s = 0;

                    if (el.getAttribute("type") === "submit") s += 40;
                    if (t === "gonder" || t === "gönder") s += 60;
                    if (t.includes("gonder") || t.includes("gönder")) s += 35;
                    if (a.includes("gonder") || a.includes("gönder")) s += 45;
                    if (title.includes("gonder") || title.includes("gönder")) s += 35;
                    if (cls.includes("send")) s += 30;

                    return {el,s};
                })
                .sort((a,b) => b.s-a.s)[0];

            if (best?.s > 5) {
                best.el.click();
                return true;
            }

            if (typeof form.requestSubmit === "function") {
                try {
                    form.requestSubmit();
                    return true;
                } catch {}
            }
        }

        const tr = target.getBoundingClientRect();

        const best = [...document.querySelectorAll('button,[role="button"]')]
            .filter(el => visible(el) && !el.disabled)
            .map(el => {
                const r = el.getBoundingClientRect();
                const t = norm(el.textContent);
                const a = norm(el.getAttribute("aria-label"));
                const title = norm(el.getAttribute("title"));
                const cls = norm(el.className || "");

                const dx = Math.abs((r.left+r.width/2)-tr.right);
                const dy = Math.abs((r.top+r.height/2)-(tr.top+tr.height/2));

                let s = 0;

                if (t === "gonder" || t === "gönder") s += 60;
                if (t.includes("gonder") || t.includes("gönder")) s += 35;
                if (a.includes("gonder") || a.includes("gönder")) s += 45;
                if (title.includes("gonder") || title.includes("gönder")) s += 40;
                if (cls.includes("send")) s += 30;
                if (el.querySelector("svg")) s += 8;

                if (dx < 220) s += 24;
                if (dx < 120) s += 15;
                if (dy < 75) s += 25;
                if (dy < 35) s += 12;

                return {el,s};
            })
            .filter(x => x.s >= 35)
            .sort((a,b) => b.s-a.s)[0];

        if (best) {
            best.el.click();
            return true;
        }

        for (const type of ["keydown","keypress","keyup"]) {
            target.dispatchEvent(new KeyboardEvent(type,{
                key:"Enter",
                code:"Enter",
                keyCode:13,
                which:13,
                bubbles:true,
                cancelable:true
            }));
        }

        return true;
    }

    async function useReply(reply) {
        const target = findMessageInput();

        if (!target) {
            flash("Önce bir konuşmayı aç",false);
            return;
        }

        setValue(target,reply.text);

        if (state.direct) {
            const ok = await trySend(target);
            flash(ok ? "Gönderildi ✓" : "Mesaj yazıldı",ok);
        } else {
            flash("Mesaj kutusuna yazıldı ✓");
        }
    }

    function tone(t) {
        if (t === "blue") return ["#9acaff","rgba(94,167,255,.28)","rgba(94,167,255,.07)"];
        return ["#ffc85b","rgba(255,173,10,.30)","rgba(255,173,10,.07)"];
    }

    function makeReply(reply) {
        const [color,border,bg] = tone(reply.tone);
        const b = document.createElement("button");

        b.type = "button";
        b.innerHTML = `
            <span style="font-weight:850">${reply.short}</span>
            <span style="margin-left:auto;color:#697586;font-size:9px">${reply.key}</span>
        `;
        b.title = reply.text;

        b.style.cssText = `
            width:100%;
            min-height:35px;
            display:flex;
            align-items:center;
            gap:8px;
            padding:7px 9px;
            border:1px solid ${border};
            border-radius:7px;
            background:${bg};
            color:${color};
            font:700 10px/1.2 Inter,Segoe UI,Arial,sans-serif;
            cursor:pointer;
            text-align:left;
        `;

        b.addEventListener("click",e => {
            e.preventDefault();
            e.stopPropagation();
            useReply(reply);
        });

        return b;
    }

    function flash(text,ok=true) {
        const host = state.minimized ? state.mini : state.panel;
        if (!host) return;

        document.getElementById("niyazi-qr-toast-v24")?.remove();

        const t = document.createElement("div");
        t.id = "niyazi-qr-toast-v24";
        t.textContent = text;

        const r = host.getBoundingClientRect();

        t.style.cssText = `
            position:fixed;
            z-index:2147483647;
            left:${Math.max(8,Math.min(window.innerWidth-190,r.left))}px;
            top:${Math.max(8,r.top-34)}px;
            padding:6px 9px;
            border-radius:7px;
            background:${ok ? "rgba(20,31,26,.98)" : "rgba(45,25,27,.98)"};
            border:1px solid ${ok ? "rgba(52,225,132,.35)" : "rgba(255,107,107,.35)"};
            color:${ok ? "#7af0ae" : "#ff9b9b"};
            font:750 10px/1 Inter,Segoe UI,Arial,sans-serif;
            box-shadow:0 8px 20px rgba(0,0,0,.30);
            pointer-events:none;
        `;

        document.body.appendChild(t);
        setTimeout(() => t.remove(),1000);
    }

    function clamp(x,y,w,h) {
        return {
            x:Math.max(6,Math.min(window.innerWidth-w-6,x)),
            y:Math.max(6,Math.min(window.innerHeight-h-6,y))
        };
    }

    function defaultPos(w,h) {
        return clamp(
            window.innerWidth-w-18,
            Math.max(90,window.innerHeight*.30),
            w,h
        );
    }

    function place(el,isMini=false) {
        const w = el.offsetWidth || (isMini ? 38 : 206);
        const h = el.offsetHeight || (isMini ? 38 : 210);

        const pos = state.x === null || state.y === null
            ? defaultPos(w,h)
            : clamp(state.x,state.y,w,h);

        el.style.left = `${Math.round(pos.x)}px`;
        el.style.top = `${Math.round(pos.y)}px`;

        if (state.x === null || state.y === null)
            savePosition(pos.x,pos.y);
    }

    function startDrag(e,el) {
        if (e.button !== 0) return;

        const r = el.getBoundingClientRect();

        state.dragging = true;
        state.dragEl = el;
        state.dragMoved = false;
        state.startX = e.clientX;
        state.startY = e.clientY;
        state.offsetX = e.clientX-r.left;
        state.offsetY = e.clientY-r.top;

        e.preventDefault();
        e.stopPropagation();
    }

    function moveDrag(e) {
        if (!state.dragging || !state.dragEl) return;

        const dx0 = Math.abs(e.clientX-state.startX);
        const dy0 = Math.abs(e.clientY-state.startY);

        if (dx0 > 3 || dy0 > 3)
            state.dragMoved = true;

        if (!state.dragMoved) return;

        const el = state.dragEl;
        const pos = clamp(
            e.clientX-state.offsetX,
            e.clientY-state.offsetY,
            el.offsetWidth,
            el.offsetHeight
        );

        el.style.left = `${Math.round(pos.x)}px`;
        el.style.top = `${Math.round(pos.y)}px`;

        savePosition(pos.x,pos.y);

        e.preventDefault();
    }

    function endDrag() {
        if (!state.dragging) return;

        state.dragging = false;
        state.dragEl = null;

        if (state.dragMoved) {
            state.suppressClick = true;

            setTimeout(() => {
                state.suppressClick = false;
                state.dragMoved = false;
            },80);
        }
    }

    function buildPanel() {
        if (state.panel) return state.panel;

        const p = document.createElement("div");
        state.panel = p;

        p.style.cssText = `
            position:fixed;
            z-index:2147483646;
            width:206px;
            display:none;
            padding:7px;
            border:1px solid rgba(72,82,96,.78);
            border-radius:11px;
            background:rgba(15,18,23,.97);
            box-shadow:0 16px 38px rgba(0,0,0,.42);
            user-select:none;
        `;

        const head = document.createElement("div");
        head.style.cssText = `
            height:29px;
            display:flex;
            align-items:center;
            gap:6px;
            padding:0 3px 6px;
            color:#ffb11a;
            font:850 10px/1 Inter,Segoe UI,Arial,sans-serif;
            cursor:move;
        `;
        head.innerHTML = `
            <span>⚡</span>
            <span>HAZIR CEVAPLAR</span>
            <span style="margin-left:auto;color:#677281">⠿</span>
        `;
        head.addEventListener("mousedown",e => startDrag(e,p));
        p.appendChild(head);

        const list = document.createElement("div");
        list.style.cssText = `
            display:flex;
            flex-direction:column;
            gap:6px;
        `;
        REPLIES.forEach(r => list.appendChild(makeReply(r)));
        p.appendChild(list);

        const footer = document.createElement("div");
        footer.style.cssText = `
            display:grid;
            grid-template-columns:1fr 64px 28px;
            gap:5px;
            margin-top:7px;
        `;

        const direct = document.createElement("button");

        function redrawDirect() {
            direct.textContent = state.direct ? "⚡ Direkt Açık" : "⚡ Direkt Kapalı";
            direct.style.color = state.direct ? "#7af0ae" : "#a1a9b5";
        }

        direct.style.cssText = `
            height:29px;
            border:1px solid rgba(75,84,97,.55);
            border-radius:7px;
            background:rgba(31,36,44,.90);
            font:800 8.5px/1 Inter,Segoe UI,Arial,sans-serif;
            cursor:pointer;
        `;
        redrawDirect();

        direct.addEventListener("click",() => {
            state.direct = !state.direct;

            try {
                localStorage.setItem(STORAGE.direct,state.direct ? "1" : "0");
            } catch {}

            redrawDirect();
        });

        const clear = document.createElement("button");
        clear.textContent = "✕ Sil";
        clear.title = "Mesaj kutusundaki yazının tamamını sil";
        clear.style.cssText = `
            height:29px;
            border:1px solid rgba(255,107,107,.28);
            border-radius:7px;
            background:rgba(255,107,107,.06);
            color:#ff9f9f;
            font:800 8.5px/1 Inter,Segoe UI,Arial,sans-serif;
            cursor:pointer;
        `;
        clear.addEventListener("click",clearMessage);

        const minimize = document.createElement("button");
        minimize.textContent = "—";
        minimize.title = "Küçült";
        minimize.style.cssText = `
            height:29px;
            border:1px solid rgba(75,84,97,.55);
            border-radius:7px;
            background:rgba(31,36,44,.90);
            color:#a1a9b5;
            font:900 13px/1 Inter,Segoe UI,Arial,sans-serif;
            cursor:pointer;
        `;
        minimize.addEventListener("click",() => {
            const r = p.getBoundingClientRect();
            savePosition(r.left,r.top);

            state.minimized = true;

            try {
                localStorage.setItem(STORAGE.minimized,"1");
            } catch {}

            refresh();
        });

        footer.appendChild(direct);
        footer.appendChild(clear);
        footer.appendChild(minimize);
        p.appendChild(footer);

        document.body.appendChild(p);
        return p;
    }

    function buildMini() {
        if (state.mini) return state.mini;

        const b = document.createElement("button");
        state.mini = b;
        b.textContent = "⚡";
        b.title = "Hazır Cevaplar — sürükle veya açmak için tıkla";

        b.style.cssText = `
            position:fixed;
            z-index:2147483646;
            width:38px;
            height:38px;
            display:none;
            border:1px solid rgba(255,173,10,.42);
            border-radius:10px;
            background:rgba(18,22,28,.97);
            color:#ffb11a;
            box-shadow:0 10px 24px rgba(0,0,0,.33);
            font:900 15px/1 Inter,Segoe UI,Arial,sans-serif;
            cursor:move;
            user-select:none;
        `;

        // V2.3 hatasının ana düzeltmesi:
        // küçük ikon da doğrudan sürüklenebilir.
        b.addEventListener("mousedown",e => startDrag(e,b));

        b.addEventListener("click",e => {
            e.preventDefault();

            if (state.suppressClick || state.dragMoved)
                return;

            const r = b.getBoundingClientRect();
            savePosition(r.left,r.top);

            state.minimized = false;

            try {
                localStorage.setItem(STORAGE.minimized,"0");
            } catch {}

            refresh();
        });

        document.body.appendChild(b);
        return b;
    }

    function hideAll() {
        if (state.panel) state.panel.style.display = "none";
        if (state.mini) state.mini.style.display = "none";
    }

    function refresh() {
        cancelAnimationFrame(state.raf);

        state.raf = requestAnimationFrame(() => {
            if (!isMessagesPage()) {
                hideAll();
                return;
            }

            const p = buildPanel();
            const m = buildMini();

            if (state.minimized) {
                p.style.display = "none";
                m.style.display = "block";
                place(m,true);
            } else {
                m.style.display = "none";
                p.style.display = "block";
                place(p,false);
            }
        });
    }

    window.__niyaziQuickDockV24Refresh = refresh;

    document.addEventListener("mousemove",moveDrag,true);
    document.addEventListener("mouseup",endDrag,true);

    document.addEventListener("keydown",e => {
        if (!isMessagesPage()) return;
        if (!e.altKey || e.ctrlKey || e.metaKey) return;

        const map = {
            "1":"ch1",
            "2":"pazar",
            "3":"onay"
        };

        const id = map[e.key];
        if (!id) return;

        const reply = REPLIES.find(x => x.id === id);
        if (!reply) return;

        e.preventDefault();
        e.stopPropagation();

        useReply(reply);
    },true);

    state.observer = new MutationObserver(refresh);

    state.observer.observe(document.documentElement,{
        childList:true,
        subtree:true,
        attributes:true,
        attributeFilter:["class","style"]
    });

    window.addEventListener("resize",refresh);
    window.addEventListener("popstate",refresh);
    window.addEventListener("hashchange",refresh);

    loadState();
    refresh();
    setInterval(refresh,1200);
})();