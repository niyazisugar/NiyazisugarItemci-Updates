(() => {
    "use strict";

    if (window.__niyazisugarAdBlockInstalledV261) {
        window.__niyazisugarAdBlockRefreshV261?.();
        return;
    }

    window.__niyazisugarAdBlockInstalledV261 = true;

    const path = String(location.pathname || "").toLocaleLowerCase("tr-TR");

    // Kimlik doğrulama sayfalarında DOM'a hiç dokunma.
    // Login ekranının boş kalmasına sebep olan agresif gizlemeyi önler.
    if (
        path.startsWith("/user/login") ||
        path.startsWith("/user/register") ||
        path.includes("forgot") ||
        path.includes("password") ||
        path.includes("oauth") ||
        path.includes("auth")
    ) {
        return;
    }

    const style = document.createElement("style");
    style.id = "niyazisugar-adblock-style-v261";
    style.textContent = `
        iframe[src*="doubleclick.net"],
        iframe[src*="googlesyndication.com"],
        iframe[src*="googleadservices.com"],
        [data-ad-slot],
        [data-ad-client],
        .adsbygoogle,
        [id^="google_ads"],
        [id*="google_ads"] {
            display:none !important;
            visibility:hidden !important;
            height:0 !important;
            min-height:0 !important;
            overflow:hidden !important;
        }
    `;

    document.documentElement.appendChild(style);

    const norm = v => String(v || "")
        .toLocaleLowerCase("tr-TR")
        .replace(/\s+/g, " ")
        .trim();

    function safeHide(el) {
        if (!el || !el.isConnected || !el.style)
            return false;

        // Asla sayfanın ana iskeletini / formunu / navigasyonunu gizleme.
        if (
            el === document.body ||
            el === document.documentElement ||
            el.matches?.("main,header,nav,form,#root,#__next,[role='main']")
        ) {
            return false;
        }

        if (
            el.querySelector?.(
                "form,input[type='password'],input[type='email'],button[type='submit']"
            )
        ) {
            return false;
        }

        const r = el.getBoundingClientRect();

        // Dev container'lara dokunma.
        if (
            r.width > window.innerWidth * 0.96 &&
            r.height > window.innerHeight * 0.45
        ) {
            return false;
        }

        el.style.setProperty("display", "none", "important");
        el.style.setProperty("visibility", "hidden", "important");

        return true;
    }

    function closestSmallContainer(el, options = {}) {
        const maxHeight = options.maxHeight ?? 380;
        const maxWidth = options.maxWidth ?? Math.max(1100, window.innerWidth * 0.92);
        const requireOverlay = options.requireOverlay ?? false;

        let cur = el;

        for (
            let i = 0;
            i < 4 &&
            cur &&
            cur !== document.body &&
            cur !== document.documentElement;
            i++, cur = cur.parentElement
        ) {
            const r = cur.getBoundingClientRect();
            const s = getComputedStyle(cur);

            if (
                r.width < 120 ||
                r.height < 20 ||
                r.height > maxHeight ||
                r.width > maxWidth
            ) {
                continue;
            }

            if (
                cur.matches?.("main,header,nav,form,#root,#__next,[role='main']")
            ) {
                continue;
            }

            if (
                cur.querySelector?.(
                    "form,input[type='password'],input[type='email'],button[type='submit']"
                )
            ) {
                continue;
            }

            const overlay =
                s.position === "fixed" ||
                s.position === "absolute" ||
                s.position === "sticky";

            if (requireOverlay && !overlay)
                continue;

            return cur;
        }

        return null;
    }

    function scan() {
        // 1) Büyük çekiliş / kampanya üst bandı:
        // sadece kendi küçük bandını gizle, üst layout container'ına çıkma.
        for (const el of document.querySelectorAll("a,div,span,p")) {
            if (el.children.length > 4)
                continue;

            const text = norm(el.textContent);

            if (!text)
                continue;

            if (
                text.includes("büyük çekiliş başladı") ||
                text.includes("buyuk cekilis basladi")
            ) {
                const r = el.getBoundingClientRect();

                if (
                    r.height > 0 &&
                    r.height <= 100 &&
                    r.width >= 250
                ) {
                    safeHide(el);
                }

                continue;
            }

            // 2) Görsel reklam popup/overlay.
            if (
                text.includes("görsele tıkla") ||
                text.includes("gorsele tikla") ||
                text.includes("kampanyaya git")
            ) {
                const box = closestSmallContainer(el, {
                    maxHeight: 560,
                    requireOverlay: true
                });

                if (box)
                    safeHide(box);

                continue;
            }

            // 3) Yalnızca tek kelime REKLAM etiketi.
            // En fazla birkaç parent yukarı çık ve küçük kutu olması şart.
            if (text === "reklam") {
                const box = closestSmallContainer(el, {
                    maxHeight: 330,
                    requireOverlay: false
                });

                if (box) {
                    const boxText = norm(box.innerText || box.textContent || "");

                    // "REKLAM VER" navigasyonu / normal menü asla gizlenmesin.
                    if (
                        !boxText.includes("reklam ver") &&
                        !boxText.includes("giriş yap") &&
                        !boxText.includes("giris yap")
                    ) {
                        safeHide(box);
                    }
                }
            }
        }
    }

    window.__niyazisugarAdBlockRefreshV261 = scan;

    let scheduled = false;

    const observer = new MutationObserver(() => {
        if (scheduled)
            return;

        scheduled = true;

        requestAnimationFrame(() => {
            scheduled = false;
            scan();
        });
    });

    observer.observe(document.documentElement, {
        childList:true,
        subtree:true
    });

    scan();
})();